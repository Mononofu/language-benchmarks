Facebook post from The Nihon Ki-in (Japan Go Association):
June 20 at 1:20am

News:
Dwango Co., Ltd which is a sponsor of the development of the A.I. Go,
"DeepZenGo" has agreed to offer the Nihon Ki-in that the members of
the Japan national team of go can play anytime against "DeepZenGo"
at Yugen no ma go sever, to strengthen the Japan national team.
It will be starting from 21 June 2017.

---

Elsewhere:

For about half a year from Wednesday, June 21, 2017 to Sunday, December 31, 2017, Go AI "DeepZenGo" is going to be a net game opponent website "During the Unseen" with the aim of supporting strengthening of the Go National team.

------

The numbering here is chronological in the cases where
I know of a time stamp. Otherwise it more or less follows
what one finds on Chinese sites.
However, these sites do not list my Zen13.sgf and Zen42.sgf,
so the numbering may be shifted by 1 or 2.

